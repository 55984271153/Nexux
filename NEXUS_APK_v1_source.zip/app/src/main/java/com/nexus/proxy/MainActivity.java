package com.nexus.proxy;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String VALID_KEY = "NEXUS-7K4M9P2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText keyInput = findViewById(R.id.keyInput);
        Button validate = findViewById(R.id.validateButton);
        Button connect = findViewById(R.id.connectButton);
        TextView status = findViewById(R.id.status);

        validate.setOnClickListener(v -> {
            String key = keyInput.getText().toString().trim().toUpperCase();
            if (VALID_KEY.equals(key)) {
                status.setText("Status: KEY VÁLIDA ✓");
                status.setTextColor(Color.rgb(102,187,106));
                connect.setEnabled(true);
            } else {
                status.setText("Status: KEY INVÁLIDA");
                status.setTextColor(Color.rgb(239,83,80));
                connect.setEnabled(false);
            }
        });

        connect.setOnClickListener(v -> {
            if ("CONECTAR".contentEquals(connect.getText())) {
                connect.setText("DESCONECTAR");
                status.setText("Status: conectado (demonstração)");
            } else {
                connect.setText("CONECTAR");
                status.setText("Status: desconectado");
            }
        });
    }
}
