# NEXUS v1

Primeira versão do aplicativo Android:
- tela NEXUS;
- validação de uma key local;
- botão conectar/desconectar em modo de demonstração.

KEY de teste:
`NEXUS-7K4M9P2`

Esta versão NÃO intercepta nem altera o tráfego de jogos e não implementa bypass de anti-cheat. O botão "Conectar" é apenas uma demonstração da interface.

Para gerar o APK, abra este projeto em Android Studio ou em um ambiente Android/Gradle compatível e execute a tarefa `assembleDebug`.
